"""Small dataset I/O and exact source-span validation."""
import json
from pathlib import Path

def read_jsonl(path):return [json.loads(line) for line in Path(path).read_text().splitlines() if line.strip()]
def write_json(path,data):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def validate(doc):
    text=doc['full_text'];entities=doc['entities'];assert len({e['id'] for e in entities})==len(entities),'Duplicate entity IDs'
    for e in entities:
        assert 0<=e['start']<e['end']<=len(text),(doc.get('document_id'),e['id'])
        assert text[e['start']:e['end']]==e['text'],(doc.get('document_id'),e['id'])
    assert not doc.get('relations',[]),'This project does not train or predict relations'
    return True
