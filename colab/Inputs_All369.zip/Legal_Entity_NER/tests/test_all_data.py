import importlib.util,random
from pathlib import Path
import torch
from src.document_windows import training_views,candidate_pairs
from src.dataset import read_jsonl,validate
from src.model import balanced_binary_loss
ROOT=Path(__file__).resolve().parents[1]

def test_all_frozen_sources_and_split():
    spec=importlib.util.spec_from_file_location('allcheck',ROOT/'scripts/check_all_data.py')
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    assert m.main()['documents']==369

def test_every_train_positive_survives_windows_with_exact_source_offsets():
    docs=read_jsonl(ROOT/'data/toan_bo/dataset/train.jsonl')
    views=training_views(docs);originals={d['document_id']:d for d in docs};seen=set()
    for v in views:
        validate(v);d=originals[v['document_id']]
        assert v['full_text']==d['full_text'][v['source_start']:v['source_end']]
        for e in v['entities']:seen.add((v['document_id'],e['id']))
    expected={(d['document_id'],e['id']) for d in docs for e in d['entities']}
    assert seen==expected
    assert max(len(v['full_text']) for v in views)<16000
    assert {v['document_id'] for v in views}==set(originals)

def test_long_nested_and_crossing_spans_are_not_truncated_into_negative_targets():
    text='X'*90
    d={'document_id':'nested','full_text':text,'entities':[
        {'id':'outer','label':'Điều','start':12,'end':68,'text':text[12:68]},
        {'id':'inner','label':'Khoản','start':20,'end':30,'text':text[20:30]}],'relations':[]}
    views=training_views([d],window_chars=32,overlap_chars=8,context_chars=4)
    assert any({e['id'] for e in v['entities']}=={'outer','inner'} for v in views)
    assert any(v['ignored_partial_entities'] for v in views)

def test_ignored_partial_targets_have_zero_loss_gradient():
    logits=torch.tensor([[1.,-1.],[.5,.5]],requires_grad=True)
    target=torch.tensor([[1.,-1.],[0.,-1.]])
    loss=balanced_binary_loss(logits,target);loss.backward()
    assert torch.isfinite(loss) and logits.grad[:,1].abs().sum()==0
    assert logits.grad[:,0].abs().sum()>0

def test_negative_only_window_with_partial_annotation_can_backpropagate():
    from test_ner import fixture
    d,model=fixture();d['entities']=[]
    d['ignored_partial_entities']=[{'label':'Điều','start':3,'end':len(d['full_text'])}]
    loss,_=model.loss(d,random.Random(2));assert torch.isfinite(loss)
    loss.backward();assert model.start.weight.grad is not None

def test_partial_span_is_ignored_by_endpoint_ranking_too():
    from src.model import endpoint_competition_loss
    logits=torch.tensor([[.2],[10.],[-.5]],requires_grad=True)
    target=torch.tensor([[1.],[-1.],[0.]])
    loss=endpoint_competition_loss(logits,target,[(0,3),(0,4),(0,5)])
    loss.backward()
    assert logits.grad[1].abs().sum()==0 and logits.grad[2].abs().sum()>0

def test_bounded_candidate_pairs_equal_exhaustive_decoder():
    rng=random.Random(81);text='abc\ndefgh\nij\nklmnop'
    offsets=[(i,i+1) for i in range(len(text))];nl=[0]
    for c in text:nl.append(nl[-1]+(c=='\n'))
    for _ in range(20):
        starts=rng.sample(range(len(text)),7);ends=rng.sample(range(len(text)),8);width=rng.randint(1,len(text))
        for prefix in [None,nl]:
            expected={(a,b+1) for a in starts for b in ends if b>=a and offsets[b][1]-offsets[a][0]<=width and (prefix is None or prefix[b+1]==prefix[a])}
            assert set(candidate_pairs(starts,ends,offsets,width,prefix))==expected
