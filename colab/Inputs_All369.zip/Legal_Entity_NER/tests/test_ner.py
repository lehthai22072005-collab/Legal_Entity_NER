import copy,importlib.util,json,random
from pathlib import Path
import pytest,torch
from src.model import EntityExtractor
from src.dataset import validate,read_jsonl
from src.decoding import fit_policy
from src.entity_task import entity_policy,evaluate_entities
from src.training import save_checkpoint,load_checkpoint
ROOT=Path(__file__).resolve().parents[1]

def preparation():
    spec=importlib.util.spec_from_file_location('prepare',ROOT/'scripts/prepare_dataset.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
def fixture():
    text='LUẬT\nĐiều 1.\n1. Nội dung.'
    def e(id,label,a,b):return {'id':id,'label':label,'start':a,'end':b,'text':text[a:b]}
    d={'document_id':'fixture','full_text':text,'docx_length':len(text),'entities':[e('a','Loại văn bản',0,4),e('b','Điều',5,12),e('c','Khoản',13,len(text))],'relations':[]}
    o=json.loads((ROOT/'configs/ontology.json').read_text());labels=[e['label'] for e in o['entities']]
    c={'encoder':'char_cnn','vocab':{c:i+1 for i,c in enumerate(sorted(set(text)))},'hidden':96,'entity_only':True,'quality_v2':True,'quality_v4':True,'balanced_entity_loss':True,'span_layout_features':True,'marker_v6':True,'context_v7':True,'active_entities':[l in {e['label'] for e in d['entities']} for l in labels],'decoder_policy':entity_policy(fit_policy([d],o,True,True))}
    return d,EntityExtractor(c,o)

def test_entire_dataset_sources_offsets_and_split():
    spec=importlib.util.spec_from_file_location('check',ROOT/'scripts/check_data.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.main()
def test_ontology_has_exact40_entities_no_relation_labels():
    o=json.loads((ROOT/'configs/ontology.json').read_text());assert len(o['entities'])==40 and 'relations' not in o
def test_only_whitespace_differences_can_project_offsets():
    m=preparation();text='Điều 1\nNội dung';a='Điều 1Nội dung';project=m.map_body_offsets(a,text)
    s,e=project(6,len(a));assert text[s:e]=='Nội dung'
    with pytest.raises(ValueError):m.map_body_offsets('Điều 1 Sai chữ',text)
def test_group_split_is_deterministic_and_keeps_related_documents():
    m=preparation();docs=[{'document_id':str(i),'category':'luat' if i<20 else 'phap_lenh','family':'shared' if i<3 else str(i),'docx_sha256':str(i),'text_sha256':str(i)} for i in range(30)]
    a=m.assign_splits(copy.deepcopy(docs),val_count=6);b=m.assign_splits(copy.deepcopy(docs),val_count=6)
    assert a==b and len({d['split'] for d in a[:3]})==1
def test_wrong_boundary_is_both_false_positive_and_false_negative():
    d,m=fixture();p=copy.deepcopy(d);p['entities'][0]['end']-=1
    result=evaluate_entities([d],[p],m.ontology)['entity_exact_span']['micro'];assert result['fp']==result['fn']==1
def test_empty_entities_do_not_produce_fake_null_true_positives():
    _,m=fixture();a={'entities':[]};metric=evaluate_entities([a],[a],m.ontology)['entity_exact_span'];assert metric['micro']['tp']==0 and metric['macro_f1_supported_labels'] is None
def test_nested_and_multiple_types_on_same_span_are_not_merged():
    d,m=fixture();e=copy.deepcopy(d['entities'][0]);e.update(id='other',label='Tên văn bản');d['entities'].append(e);assert validate(d)
    score=evaluate_entities([d],[copy.deepcopy(d)],m.ontology)['entity_exact_span']['micro'];assert score['tp']==4 and score['f1']==1
def test_bad_source_evidence_is_rejected():
    d,_=fixture();d['entities'][0]['text']='Sai';
    with pytest.raises(AssertionError):validate(d)
def test_loss_backpropagates_entity_heads_without_relation_access():
    torch.set_num_threads(2);d,m=fixture()
    class Poison:
        def __iter__(self):raise AssertionError('Read relation annotations')
    d['relations']=Poison();loss,details=m.loss(d,random.Random(4));assert torch.isfinite(loss);loss.backward()
    assert m.encoder.emb.weight.grad.abs().sum()>0 and m.start.weight.grad.abs().sum()>0 and m.span_type.weight.grad.abs().sum()>0
    assert not any(k.startswith(('pair.','type_emb.','active_relations','null_parent')) for k in m.state_dict())
def test_inference_cannot_accept_gold_endpoints():
    _,m=fixture()
    with pytest.raises(ValueError):m.infer('Nội dung',oracle_entities=[])
def test_checkpoint_restore_keeps_exact_entity_weights(tmp_path):
    _,m=fixture();save_checkpoint(tmp_path,m,{'thresholds':{'boundary_threshold':.99,'span_threshold':.99},'decoder_topk':8})
    restored,_=load_checkpoint(tmp_path)
    assert set(restored.state_dict())==set(m.state_dict())
    assert all(torch.equal(restored.state_dict()[k],v) for k,v in m.state_dict().items())
def test_pipeline_missing_fields_are_null_and_external_context_refused(tmp_path):
    from src.pipeline import predict
    _,m=fixture()
    with torch.no_grad():m.start.weight.zero_();m.start.bias.fill_(-100)
    save_checkpoint(tmp_path,m,{'thresholds':{'boundary_threshold':.99,'span_threshold':.99},'decoder_topk':8})
    candidates=list((ROOT/'data/data_tho').glob('*/*/source.docx'))+list((ROOT/'data/toan_bo/source_docx').glob('*.docx'))+list((ROOT/'tests/fixtures').glob('*.docx'))
    source=min(candidates,key=lambda p:p.stat().st_size)
    out=predict(source,tmp_path);assert 'relations' not in out and out['entities']==[] and len(out['document_metadata'])==12
    assert all(v is None for v in out['document_metadata'].values())
    with pytest.raises(ValueError):predict(source,tmp_path,context_text='Nguồn ngoài Word')
