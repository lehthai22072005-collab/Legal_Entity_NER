"""Checks source hashes, DOCX-only offsets and whole-family split separation."""
import hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from src.dataset import read_jsonl,validate

def main():
    if not (ROOT/'data/source_manifest.json').exists():
        sys.path.insert(0,str(ROOT/'scripts'))
        from check_all_data import main as all_data_check
        return all_data_check()
    sources=json.loads((ROOT/'data/source_manifest.json').read_text());assert len(sources)==119
    checked=0
    for d in sources:
        for f in d['files']:
            p=ROOT/f['path']
            with p.open('rb') as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==f['sha256']
            checked+=1
    train=read_jsonl(ROOT/'data/dataset/train.jsonl');val=read_jsonl(ROOT/'data/dataset/val.jsonl');assert (len(train),len(val))==(101,18)
    for field in ['document_id','group_id','docx_sha256','text_sha256','family']:assert not {d[field] for d in train}&{d[field] for d in val},field
    for d in train+val:
        assert len(d['full_text'])==d['docx_length'] and d['input_view']=='docx' and not d['relations'];validate(d)
    assert len(json.loads((ROOT/'configs/ontology.json').read_text())['entities'])==40
    print('DATA_PASS',len(sources),'unique documents / 101Train /18Validation; source hashes',checked,'checked; exact offsets and groups disjoint; no relation targets')

if __name__=='__main__':main()
