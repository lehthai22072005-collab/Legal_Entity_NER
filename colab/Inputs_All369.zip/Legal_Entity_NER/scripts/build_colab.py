"""One concise notebook, with private source/data embedded and no old weights."""
import base64,hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'colab'
def main():
    OUT.mkdir(exist_ok=True);archive=OUT/'Inputs_119.zip'
    if archive.exists():raise FileExistsError('Preserve the frozen input; select a new revision')
    files=[]
    for name in ['src','scripts','tests','configs','data/data_tho','data/dataset','resources/phobert-base']:
        files.extend(p for p in (ROOT/name).rglob('*') if p.is_file() and not any(x in p.parts for x in ['__pycache__','.cache']) and p.suffix not in ['.bin','.safetensors'])
    files.extend(ROOT/n for n in ['data/source_manifest.json','data/source_index.json','README.md','requirements.txt','app.py'])
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(set(files)):z.write(p,ROOT.name+'/'+str(p.relative_to(ROOT)))
    with zipfile.ZipFile(archive) as z:assert z.testzip() is None
    raw=archive.read_bytes();digest=hashlib.sha256(raw).hexdigest();encoded=base64.b64encode(raw).decode();payload='\n'.join(repr(encoded[i:i+1000]) for i in range(0,len(encoded),1000))
    md=lambda s:{'cell_type':'markdown','metadata':{},'source':s.splitlines(keepends=True)}
    code=lambda s:{'cell_type':'code','metadata':{},'source':s.splitlines(keepends=True),'outputs':[],'execution_count':None}
    cells=[md('''# PhoBERT + Span Head — 119 văn bản riêng biệt
Nguồn được yêu cầu gồm120 thư mục; một văn bản bị lưu trùng nên dùng119 văn bản:77Luật/42Pháplệnh,101Train/18Validation,0Test. Chia theo nhóm tài liệu, không chia chunk giữa hai tập.

Chỉ nhận dạng40loại thực thể, không quan hệ. Đầu vào chỉ nội dungDOCX; thuộc tính ngoàiWord trảnull. Khởi tạo từpublicPhoBERT-base gốc theo revision/SHA cố định, không dùng checkpointE1 hoặcSilver. Chọn checkpoint bằng trung bìnhMicro/Macro-F1 trênValidation. Không tự tuyên bố đạt80% nếu số thực tế chưa đạt.
'''),code('''import os,sys,subprocess,torch
os.environ['USE_TF']='0';os.environ['TOKENIZERS_PARALLELISM']='false'
assert torch.cuda.is_available(), 'Chưa được cấp GPU; không tự train CPU.'
print('ALLOCATED_GPU',torch.cuda.get_device_name(0),torch.__version__)
subprocess.run([sys.executable,'-m','pip','install','-q','transformers==4.51.3','tokenizers>=0.21,<0.22','pyvi==0.1.1','pytest>=8,<10','huggingface_hub'],check=True)
'''),code('''#@title Khôi phục mã nguồn và dữ liệu đã kiểm tra
from pathlib import Path
import base64,hashlib,io,json,zipfile
workspace=Path('/content/legal_ner_119');workspace.mkdir(parents=True,exist_ok=True)
raw=base64.b64decode(\n'''+payload+'''\n)
assert hashlib.sha256(raw).hexdigest()=='''+repr(digest)+'''
with zipfile.ZipFile(io.BytesIO(raw)) as z:
 assert z.testzip() is None
 assert all((workspace/n).resolve().is_relative_to(workspace.resolve()) for n in z.namelist())
 z.extractall(workspace)
root=workspace/'Legal_Entity_NER'
print('FROZEN_INPUTS_RESTORED',root)
'''),code('''# Chạy worker; kết nối trình duyệt mất không tự làm mất log/checkpoint.
run='phobert_span_119_v1';report=root/'reports'/run;report.mkdir(parents=True,exist_ok=True)
assert not (report/'worker_status.json').exists(), 'Đã có worker, đọc trạng thái thay vì chạy trùng.'
with (report/'worker.log').open('w') as log:
 process=subprocess.Popen([sys.executable,'-u','scripts/run_colab.py'],cwd=root,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
print('WORKER_STARTED',process.pid)
from google.colab import output
from IPython.display import JSON,Javascript,display
allowed={'trained_zip':workspace/'Legal_Entity_NER_119_Trained.zip','results':report/'RESULTS.json','history':report/'history.json'}
def transfer(key,offset=0,limit=4*1024*1024):
 path=allowed[key];offset=int(offset);limit=min(int(limit),4*1024*1024)
 assert offset>=0 and limit>0
 with path.open('rb') as stream:stream.seek(offset);block=stream.read(limit)
 return JSON({'offset':offset,'total':path.stat().st_size,'bytes':len(block),'base64':base64.b64encode(block).decode()})
def poll():
 p=report/'worker_status.json';s=json.loads(p.read_text()) if p.exists() else {'phase':'STARTING'}
 for name in ['progress.json','history.json']:
  try:
   if (report/name).exists():s[name]=json.loads((report/name).read_text())
  except ValueError:pass
 p=report/'train.log' if (report/'train.log').exists() else report/'worker.log'
 if p.exists():
  with p.open('rb') as f:f.seek(max(0,p.stat().st_size-4000));s['log_tail']=f.read().decode(errors='replace')
 return JSON(s)
output.register_callback('ner119.status',poll);output.register_callback('ner119.transfer',transfer)
display(Javascript("window.nckhPoll=()=>google.colab.kernel.invokeFunction('ner119.status',[],{});window.nckhTransfer=(key,offset,limit)=>google.colab.kernel.invokeFunction('ner119.transfer',[key,offset,limit],{});document.body.appendChild(Object.assign(document.createElement('pre'),{textContent:'NER119_WORKER_MONITOR_READY'}));"))
'''),code('''state=poll().data
print(json.dumps(state,ensure_ascii=False,indent=2))
'''),code('''state=json.loads((report/'worker_status.json').read_text());assert state['phase']=='COMPLETE',state
from google.colab import files
files.download(state['artifact']['path'])
''')]
    for i,c in enumerate(cells):
        c['id']='ner119_'+str(i)
        if c['cell_type']=='code':compile(''.join(c['source']),'<ner119_'+str(i)+'>','exec')
    cells[2]['metadata']['cellView']='form'
    book={'nbformat':4,'nbformat_minor':5,'metadata':{'accelerator':'GPU','kernelspec':{'display_name':'Python3','language':'python','name':'python3'}},'cells':cells}
    path=OUT/'Train_PhoBERT_NER_119.ipynb';path.write_text(json.dumps(book,ensure_ascii=False,indent=1))
    record={'status':'READY_NOT_TRAINED','input_bytes':len(raw),'input_sha256':digest,'notebook_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'source_documents':119,'train_documents':101,'validation_documents':18,'official_pretrained_only':True}
    (OUT/'INPUT_MANIFEST.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
if __name__=='__main__':main()
