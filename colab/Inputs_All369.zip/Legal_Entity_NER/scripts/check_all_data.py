"""Frozen ALL-data preflight, using source bytes rather than declared counts alone."""
import hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from src.dataset import read_jsonl,validate

def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def main():
    folder=ROOT/'data/toan_bo'
    manifest=json.loads((folder/'dataset/manifest.json').read_text())
    sources=json.loads((folder/'source_manifest.json').read_text())
    bundle_path=folder/'BUNDLE_MODE.json'
    bundle=json.loads(bundle_path.read_text()) if bundle_path.exists() else None
    if bundle:
        assert bundle['mode']=='normalized_training_inputs_originals_kept_locally'
        assert bundle['source_manifest_sha256']==sha(folder/'source_manifest.json')
        assert bundle['dataset_files']=={n:sha(folder/'dataset'/n) for n in ['train.jsonl','val.jsonl','manifest.json']}
        assert bundle['local_source_preflight']['source_hashes_verified'] is True
    train=read_jsonl(folder/'dataset/train.jsonl');val=read_jsonl(folder/'dataset/val.jsonl')
    assert (len(train),len(val))==(manifest['train_documents'],manifest['validation_documents'])==(314,55)
    assert len(sources)==manifest['unique_documents']==len(train)+len(val)==369
    docs={d['document_id']:d for d in train+val};assert len(docs)==369
    for field in ['document_id','group_id','docx_sha256','text_sha256','family']:
        a={d[field] for d in train if d.get(field)};b={d[field] for d in val if d.get(field)}
        assert not a&b,('Leakage',field)
    for row in manifest['documents']:
        d=docs[row['document_id']]
        assert sha_text(d['full_text'])==d['text_sha256']==row['text_sha256']
        assert d['group_id']==row['group_id']
    labels={e['label'] for e in json.loads((ROOT/'configs/ontology.json').read_text())['entities']}
    assert len(labels)==40
    source_docx_count=0;export_only_count=0
    for source in sources:
        d=docs[source['document_id']]
        if not bundle:assert sha(ROOT/source['json_path'])==source['json_sha256']
        bundled=folder/'source_docx'/(source['document_id']+'.docx')
        original=Path(source['source_docx_original']) if source['source_docx_original'] else None
        if source['source_text_origin']=='original_docx_reparsed':
            p=bundled if bundled.exists() else original
            assert source['docx_sha256']==d['docx_sha256']
            if not bundle:assert p and p.exists() and sha(p)==source['docx_sha256']
            source_docx_count+=1
        else:
            assert original is None and source['docx_sha256'] is None
            assert source['source_text_origin']=='reviewed_annotation_export_body_original_docx_unavailable'
            export_only_count+=1
        assert d['input_view']=='docx' and len(d['full_text'])==d['docx_length'];validate(d)
        assert {e['label'] for e in d['entities']}<=labels
    result={'status':'OFFLINE_DATA_CHECK_PASS','documents':369,'train':314,'validation':55,
            'original_docx_available':source_docx_count,'exported_word_body_only':export_only_count,
            'independent_gold_claimed':False,'source_hashes_verified':not bool(bundle),'offsets_verified':True,
            'original_source_checks':'verified_before_packaging_locally' if bundle else 'verified_from_original_bytes_here'}
    print(json.dumps(result,ensure_ascii=False));return result

def sha_text(text):return hashlib.sha256(text.encode()).hexdigest()

if __name__=='__main__':main()
