"""Freeze DOCX-only targets and a document/family grouped split, before SGD."""
import collections,csv,difflib,hashlib,json,random,re,sys,unicodedata
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from src.docx_parser import parse_docx
from src.dataset import write_json,validate

def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def canonical_family(title):
    title=unicodedata.normalize('NFC',title).casefold()
    title=re.sub(r'\s+số\s+(?:không số|\S*\d\S*).*$', '',title)
    title=re.sub(r'sửa đổi\s*,?\s*bổ sung\s*(?:một số\s*)?(?:điều\s*\d*\s*)?(?:của\s*)?','',title)
    title=re.sub(r'^(?:luật|pháp lệnh)\s*','',title)
    return re.sub(r'\W+',' ',title).strip()

def map_body_offsets(annotation,word):
    if annotation==word:return lambda a,b:(a,b)
    # Teacher-tool exports sometimes omit a paragraph separator. Only this
    # mechanical difference can be projected; no missing legal words are fixed.
    if re.sub(r'\s+','',annotation)!=re.sub(r'\s+','',word):
        raise ValueError('Source and annotation contain different non-whitespace characters')
    amap=[i for i,c in enumerate(annotation) if not c.isspace()]
    wmap=[i for i,c in enumerate(word) if not c.isspace()]
    correspondence=dict(zip(amap,wmap))
    def project(a,b):
        source=[i for i in range(a,b) if i in correspondence]
        if not source:raise ValueError('Whitespace-only entity is not extractable')
        s,e=correspondence[source[0]],correspondence[source[-1]]+1
        # Preserve existing surrounding whitespace when the characters exist.
        left=annotation[a:source[0]];right=annotation[source[-1]+1:b]
        if left and s>=len(left) and word[s-len(left):s]==left:s-=len(left)
        if right and word[e:e+len(right)]==right:e+=len(right)
        assert re.sub(r'\s+','',annotation[a:b])==re.sub(r'\s+','',word[s:e])
        return s,e
    return project

def assign_splits(docs,seed=20261117,val_count=18):
    parent=list(range(len(docs)))
    def find(x):
        while parent[x]!=x:parent[x]=parent[parent[x]];x=parent[x]
        return x
    def join(a,b):parent[find(a)]=find(b)
    for i,a in enumerate(docs):
        for j,b in enumerate(docs[:i]):
            if a['docx_sha256']==b['docx_sha256'] or a['text_sha256']==b['text_sha256'] or a['family']==b['family']:join(i,j)
    groups=collections.defaultdict(list)
    for i,d in enumerate(docs):groups[find(i)].append(d)
    blocks=sorted(groups.values(),key=lambda g:tuple(d['document_id'] for d in g));random.Random(seed).shuffle(blocks)
    # DP selects complete groups; match about 12 laws + 6 ordinances without
    # looking at label correctness, predictions, or experiment scores.
    states={(0,0):[]}
    for i,g in enumerate(blocks):
        laws=sum(d['category']=='luat' for d in g)
        for (n,l),chosen in list(states.items()):
            key=(n+len(g),l+laws)
            if key[0]<=val_count+3 and key not in states:states[key]=chosen+[i]
    target_laws=round(val_count*sum(d['category']=='luat' for d in docs)/len(docs))
    n,l=min(states,key=lambda x:(abs(x[0]-val_count),abs(x[1]-target_laws)))
    chosen={d['document_id'] for i in states[(n,l)] for d in blocks[i]}
    for i,g in enumerate(blocks):
        for d in g:d['group_id']='group_'+str(i);d['split']='validation' if d['document_id'] in chosen else 'train'
    return docs

def main():
    out=ROOT/'data/dataset'
    if out.exists():raise FileExistsError('Frozen dataset exists; use a new version to change it')
    ontology=json.loads((ROOT/'configs/ontology.json').read_text());known={e['label'] for e in ontology['entities']}
    docs=[];issues=[];projections=[];sources=[];stats=collections.Counter()
    index=json.loads((ROOT/'data/source_index.json').read_text())
    for item in sorted(index,key=lambda x:(x['category'],x['document_id'])):
        raw=ROOT/item['json_path'];source=ROOT/item['source_docx_path'];parsed=parse_docx(source)
        a=json.loads(raw.read_text(encoding='utf-8-sig'));word=parsed['canonical_text'];text=a['full_text']
        delimiter='--- THÔNG TIN THUỘC TÍNH & LƯỢC ĐỒ TỪ FILE JSON ---'
        cut=text.find(delimiter)
        if text.startswith(word):body=text[:len(word)]
        elif cut>=0:body=text[:cut].rstrip('\r\n')
        else:body=text
        project=map_body_offsets(body,word);entities=[];seen=set()
        for e in a['entities']:
            s,z=e['start'],e['end']
            if s>=len(body) or z>len(body):
                stats['supplemental_entities_excluded']+=1
                if not (0<=s<z<=len(text) and text[s:z]==e['text']):stats['bad_offsets_outside_word_excluded']+=1
                continue
            if not(0<=s<z<=len(text) and text[s:z]==e['text']):raise ValueError(('Invalid Word-side offset',item['document_id'],e['id']))
            if e['label'] not in known:
                issues.append({'document_id':item['document_id'],'entity_id':e['id'],'issue':'LABEL_OUTSIDE_FIXED40','label':e['label'],'status':'NEEDS_HUMAN_REVIEW','used_as_target':False});continue
            start,end=project(s,z);key=(e['label'],start,end)
            if key in seen:stats['duplicate_typed_spans_merged']+=1;continue
            seen.add(key);target={**e,'start':start,'end':end,'text':word[start:end],'origin':'docx','status':'user_reviewed_source_projected_not_independent_gold'}
            entities.append(target)
            if (s,z,e['text'])!=(start,end,target['text']):projections.append({'document_id':item['document_id'],'entity_id':e['id'],'old':[s,z],'new':[start,end],'reason':'Whitespace-only teacher-tool to canonical-DOCX alignment','words_changed':False})
        title=a.get('document_metadata',{}).get('ten_van_ban') or next((e['text'] for e in entities if e['label']=='Tên văn bản'),item['document_id'])
        d={'document_id':item['document_id'],'category':item['category'],'family':canonical_family(title),'full_text':word,'docx_length':len(word),
           'docx_sha256':parsed['docx_sha256'],'text_sha256':parsed['text_sha256'],'export_sha256':sha(raw),'entities':entities,'relations':[],
           'input_view':'docx','source_issues':parsed['source_issues'],'review_status':'user_reported_reviewed_not_independent_test_gold'}
        validate(d);docs.append(d)
        folder=source.parent;sources.append({**item,'files':[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(folder.iterdir()) if p.is_file()]})
    assert len(docs)==len({d['document_id'] for d in docs})==119
    docs=assign_splits(docs);out.mkdir(parents=True)
    for split,name in [('train','train'),('validation','val')]:
        rows=[d for d in docs if d['split']==split]
        (out/(name+'.jsonl')).write_text(''.join(json.dumps(d,ensure_ascii=False)+'\n' for d in rows))
    manifest={'seed':20261117,'requested_folders':120,'unique_documents':len(docs),'train_documents':sum(d['split']=='train' for d in docs),'validation_documents':sum(d['split']=='validation' for d in docs),'test_documents':0,
              'policy':'Whole documents and family/source groups, roughly85/15 before fitting; official pretrained encoder only; no old fitted checkpoint',
              'documents':[{k:d[k] for k in ['document_id','category','split','family','group_id','docx_sha256','text_sha256','export_sha256']} for d in docs]}
    write_json(out/'manifest.json',manifest);write_json(out/'label_map.json',ontology);write_json(ROOT/'data/source_manifest.json',sources)
    with (out/'split_manifest.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(manifest['documents'][0]));w.writeheader();w.writerows(manifest['documents'])
    support={}
    for split in ['train','validation']:
        rows=[d for d in docs if d['split']==split];c=collections.Counter(e['label'] for d in rows for e in d['entities'])
        support[split]={'documents':len(rows),'entities':sum(c.values()),'characters':sum(len(d['full_text']) for d in rows),'per_label':{e['label']:c[e['label']] for e in ontology['entities']},'forms':dict(collections.Counter(d['category'] for d in rows))}
    write_json(out/'statistics.json',support);write_json(ROOT/'reports/DATA_AUDIT.json',{'status':'DOCX_TARGETS_VALID','unique_documents':len(docs),'counts':support,'excluded_counts':stats,'unknown_label_cases':issues,'offset_projection_count':len(projections),'source_review_status':'User says reviewed; not independently double-reviewed Gold','raw_files_changed':False})
    write_json(ROOT/'reports/OFFSET_PROJECTIONS.json',projections)
    print(json.dumps({'manifest':{k:v for k,v in manifest.items() if k!='documents'},'counts':support,'excluded':stats,'unknown_label_cases':len(issues),'whitespace_projections':len(projections)},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
