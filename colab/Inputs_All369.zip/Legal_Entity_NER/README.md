# Chạy bộ dữ liệu toàn kho — 369 văn bản

Đợt hiện tại dùng 369 văn bản riêng biệt: **314 Train / 55 Validation**. Các bản xuất trùng đã loại khỏi phép đếm; hai trường hợp chưa đủ điều kiện được ghi trong `reports/toan_bo/EXCLUDED_DOCUMENTS.json`. Dữ liệu được giữ riêng trong `data/toan_bo`, không ghi đè bộ 119 trước đó.

Notebook: `colab/toan_bo/r3/Train_PhoBERT_NER_All369.ipynb`. Chọn **Runtime → Change runtime type → T4 GPU → Save → Runtime → Run all**. Notebook đã chứa mã nguồn, tokenizer, dữ liệu và bằng chứng nguồn; tự tải pretrained PhoBERT-base chính thức và kiểm tra SHA. Không cần upload thêm file. Không nạp trọng số đã fine-tune của mô hình cũ.

Huấn luyện tối đa 12 epoch, dừng sớm theo Validation; đầu ra chỉ thực thể. Mỗi cửa sổ Train giữ offset về văn bản gốc, bảo toàn toàn bộ mẫu dương và che các nhãn bị cắt tại biên. Validation và báo cáo cuối đánh giá exact-span trên toàn văn, không tính mỗi cửa sổ như một văn bản độc lập.

**Giới hạn nguồn:** 217 văn bản có DOCX gốc; 152 văn bản chỉ có phần nội dung Word từ bản xuất gán nhãn, chưa đối chiếu được DOCX gốc. Các vùng thuộc tính/lược đồ bổ sung ngoài Word bị loại. Nhãn được người dùng kiểm tra không đồng nghĩa với Gold đánh giá độc lập. Chưa có kết quả train mới hoặc Test độc lập.

Đợi ô theo dõi báo `COMPLETE`; ô cuối tải `Legal_Entity_NER_All369_Trained.zip`. Kết quả nằm trong `reports/phobert_span_all369_v1/RESULTS.json`, checkpoint trong `checkpoints/phobert_span_all369_v1/`. Nếu notebook báo `FAILED`, giữ trang để đọc log; không chạy worker trùng. Chỉ tải trang chưa đủ để bắt đầu huấn luyện.

Cấu hình: `configs/experiment_all.json`. Kiểm tra dữ liệu bằng `python scripts/check_all_data.py`; chạy tests bằng `USE_TF=0 python -m pytest tests -q`. Worker Colab thực hiện cả hai trước khi train. Kiểm tra offline hiện tại: **19 tests PASS**; đây không phải Precision/Recall/F1.

---

# Legal Entity NER

Hệ thống nhận dạng thực thể trong văn bản pháp luật Việt Nam bằng PhoBERT-base + đầu span (start/end và MLP), tinh chỉnh ký tự/CNN, learned marker adapter và bộ chọn span fit từ Train. Một mô hình thực thể, không huấn luyện quan hệ. Đầu vào suy luận duy nhất là DOCX; không tự điền dữ liệu từ web, thông tin không tìm thấy trả null.

## Dữ liệu lần này

Drive có78thư mụcLuật và42Pháplệnh. Văn bản97_2025_QH15_179407 bị lưu hai lần (một folder mang tênKhong_so_2324), hai bảnJSON/CSV giốngSHA. Sau loại bản sao còn119nguồn:77Luật/42Pháplệnh. Thư mục52_2024_QH15_173625 trênDrive trống; dùngJSON/CSV cùngvănbản trongDocuments/ket_qua_gan_nhan và ghi rõ provenance.

Chia101Train/18Validation (~85/15), giữ cả văn bản và nhóm cùng họ trong một tập. KhôngTestđộc lập. Khởi tạo từPhoBERT-base công khai chưa fine-tune, không resumeE1 vì các văn bản từng học có thể nằm trongValidationmới. Bộ40nhãn giữ nguyên; nhãn không có mẫu dương báoN/A.

Giữrawnguyênvẹn. Một sốoffset ở phầnweb bổ sung bị lệch; vì nằmngoàiWord nên không đưa vào target. Ba tài liệu khác dấu xuống dòng giữaDOCX vàtool được ánh xạ lại ký tự, không sửa lời luật; nhật ký tại reports/OFFSET_PROJECTIONS.json. Bốn nhãn ngoài40loại được ghiNEEDS_HUMAN_REVIEW, không tự đổi tên.

## Thư mục

- configs/: ontology40thực thể và cấu hình huấn luyện.
- data/data_tho/luat/, phap_lenh/: DOCX vàJSON/CSVgốc cho119nguồn.
- data/dataset/: train.jsonl, val.jsonl, label_map, manifest, phân bố nhãn vàCSVchia tập.
- src/: parser, tokenizer/cănchỉnhoffset, mô hình, loss/training, decoder vàmetric.
- scripts/: prepare_dataset, check_data, train, evaluate, predict và bộ chạy/đónggóiColab.
- checkpoints/: chỉ xuất hiện model.pt sau khi train thật.
- resources/phobert-base/: tokenizer/BPE; trọng số pretrained gốc chỉ tải khi train.
- colab/: một notebook thực thi vàinput/hashđãđóngbăng.
- tests/: kiểm tra nguồn/split, offset, loss, khôi phụccheckpoint vànull.
- reports/: kiểmtoán, log, FP/FN vàkếtquả đo thật.

## Huấn luyện Colab

Mở colab/Train_PhoBERT_NER_119.ipynb, chọnGPUđược cấp hợp lệ, chạy lần lượtGPUcheck→restoreinputs→worker→monitor. Worker tựkiểmdata/tests, tải publicPhoBERT theo revision/SHA, train tối đa20epochs (earlystop5, ít nhất8), chọn checkpoint bằngmeanMicro/MacroF1 củaValidation, chọnthreshold rồi lưu prediction/metrics/ZIP. KhôngtựchuyểnsangtrainCPU hoặc tựbáođạt80%.

Notebook chưa chạy thành công thì chưa có điểm mới. Không dùngF1của119nguồn để gọi là điểm độc lập hoặc so trực tiếp vớiF1tập50cũ vì split khác nhau.

## Chạy demo sau khi có checkpoint

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
USE_TF=0 .venv/bin/python -m streamlit run app.py
```

Dùngterminal: `.venv/bin/python scripts/predict.py /duong/dan/vanban.docx --output ket_qua.json`.

Kiểmdata: `python3 scripts/check_data.py`. Kiểmthử: `USE_TF=0 .venv/bin/python -m pytest tests -q`.
